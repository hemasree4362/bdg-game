document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('register-form');
    const loginForm = document.getElementById('login-form');
    const registerSection = document.getElementById('register-section');
    const loginSection = document.getElementById('login-section');
    const welcomeSection = document.getElementById('welcome-section');
    const welcomeMessage = document.getElementById('welcome-message');
    const errorMessage = document.getElementById('error-message');
    const tabSection = document.getElementById('tab-section');

    // Mock database of registered users (for demo purposes)
    const users = [];

    // Show Register Section
    window.showRegister = function() {
        registerSection.style.display = 'block';
        loginSection.style.display = 'none';
        welcomeSection.style.display = 'none';
    }

    // Show Login Section
    window.showLogin = function() {
        loginSection.style.display = 'block';
        registerSection.style.display = 'none';
        welcomeSection.style.display = 'none';
    }

    // Register form submit handler
    registerForm.addEventListener('submit', function(event) {
        event.preventDefault();

        // Perform form validation (client-side)
        const firstname = document.getElementById('firstname').value.trim();
        const lastname = document.getElementById('lastname').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const email = document.getElementById('email').value.trim();
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        const termsChecked = document.getElementById('terms').checked;

        if (!firstname || !lastname || !phone || !email || !username || !password || !confirmPassword || !termsChecked) {
            errorMessage.textContent = 'Please fill in all fields and agree to the terms.';
            return;
        }

        // Phone number validation (exactly 10 digits)
        if (phone.length !== 10 || !/^\d{10}$/.test(phone)) {
            errorMessage.textContent = 'Please enter a valid 10-digit phone number.';
            return;
        }

        if (password !== confirmPassword) {
            errorMessage.textContent = 'Passwords do not match.';
            return;
        }

        // Check if username already exists
        const existingUser = users.find(u => u.username === username);
        if (existingUser) {
            errorMessage.textContent = 'Username already exists.';
            return;
        }

        // Add new user to mock database
        users.push({ firstname, lastname, phone, email, username, password });

        // Show login section after registration
        registerSection.style.display = 'none';
        loginSection.style.display = 'block';
        errorMessage.textContent = '';
    });

    // Login form submit handler
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();

        // Perform login validation (client-side)
        const loginUsername = document.getElementById('login-username').value.trim();
        const loginPassword = document.getElementById('login-password').value;

        // Validate login credentials
        const user = users.find(u => u.username === loginUsername && u.password === loginPassword);

        if (!user) {
            errorMessage.textContent = 'Invalid username or password.';
            return;
        }

        // Clear error message
        errorMessage.textContent = '';

        // Display welcome message

    });
});
