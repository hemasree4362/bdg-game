const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');

// Middleware setup
app.use(session({ secret: 'secret-key', resave: false, saveUninitialized: true }));
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Add the route for the root URL
app.get('/', (req, res) => {
    res.redirect('/login'); // Redirect to the login page
});

// Route for login/registration page
app.get('/login', (req, res) => {
    res.render('login'); // Render the login view
});

app.post('/register', (req, res) => {
    // Handle registration logic (e.g., save user to database)
    try {
        // Registration logic here
        res.redirect('/login');
    } catch (err) {
        console.error(err);
        res.redirect('/login');
    }
});

app.post('/login', (req, res) => {
  try {
    // Handle login logic (e.g., verify user credentials)
    console.log('Login credentials:', req.body.username, req.body.password);
    if (/* login logic here */) {
      req.session.user = req.body.username;
      console.log('Session user set:', req.session.user);
      req.session.save();
      console.log('Session saved');
      res.redirect('/game');
    } else {
      console.log('Invalid login credentials');
      res.redirect('/login');
    }
  } catch (err) {
    console.error('Error during login:', err);
    res.redirect('/login');
  }
});

// Middleware to protect routes
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/login');
    }
}

// Route for BDG game
app.get('/game', isAuthenticated, (req, res) => {
    res.render('game'); // Render the BDG game view
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});